package com.example.Aura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuraApplicationTests {

	@Test
	void contextLoads() {
	}

}
