package com.example.Aura.model.Enums;

public enum Level { BEGINNER , INTERMEDIATE , ADVANCED }
