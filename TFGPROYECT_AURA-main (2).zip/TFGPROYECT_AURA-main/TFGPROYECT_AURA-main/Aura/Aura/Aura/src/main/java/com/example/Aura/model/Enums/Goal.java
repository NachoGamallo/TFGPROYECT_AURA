package com.example.Aura.model.Enums;

public enum Goal { FAT_LOSS , MUSCLE_GAIN , RECOMPOSITION }
