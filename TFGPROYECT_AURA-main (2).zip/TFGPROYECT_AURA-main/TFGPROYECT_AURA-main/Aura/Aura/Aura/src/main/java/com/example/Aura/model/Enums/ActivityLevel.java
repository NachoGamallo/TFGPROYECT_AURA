package com.example.Aura.model.Enums;

public enum ActivityLevel { SEDENTARY , LIGHT , MODERATE , HIGH , ATHLETE }
