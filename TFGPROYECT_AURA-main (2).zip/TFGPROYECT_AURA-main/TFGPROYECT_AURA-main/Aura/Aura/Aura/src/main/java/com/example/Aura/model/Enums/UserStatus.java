package com.example.Aura.model.Enums;

public enum UserStatus { ACTIVE , BLOCKED }