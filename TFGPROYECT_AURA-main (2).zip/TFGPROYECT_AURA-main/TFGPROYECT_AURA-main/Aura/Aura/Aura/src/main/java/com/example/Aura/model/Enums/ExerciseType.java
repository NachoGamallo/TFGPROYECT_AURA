package com.example.Aura.model.Enums;

public enum ExerciseType { STRENGTH , CALISTHENICS , CARDIO }