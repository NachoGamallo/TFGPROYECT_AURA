package com.example.Aura.model.Enums;

public enum UserPhase { CUTTING , BULKING , MAINTENANCE }
