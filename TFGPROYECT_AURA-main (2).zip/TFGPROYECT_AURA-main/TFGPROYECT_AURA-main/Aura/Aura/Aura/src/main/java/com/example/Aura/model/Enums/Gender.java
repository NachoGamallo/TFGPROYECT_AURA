package com.example.Aura.model.Enums;

public enum Gender { MALE , FEMALE , OTHER }
