package com.example.Aura.dto.request;

import lombok.Data;

@Data
public class LogInRequest {

    private String email;
    private String pass;

}
